# Code refactoring chain evidence

The plan schedules 36 chains through 20 hops. Each chain directory contains
its initial code, saved checkpoints, input/response files and final status.
The task specifications and requirements are under tasks. Evaluations, the
per-requirement records and the saved aggregate are at the top level. The
frozen evaluator source and oracle snapshot are under source.

Run python3 recurrence.py to verify the checkpoint hashes and generate a CSV
by task, model family and reminder condition. The numerator counts equal
saved bytes at hops t and t-2. The denominator counts every available pair
with t >= 2, including comparisons to the initial artifact at hop 0.
The recurrence script reads candidate code as data.
