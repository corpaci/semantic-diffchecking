def law(op, x, y, z):
    lhs = op(op(x, y), z)
    rhs = op(x, op(y, z))
    return lhs == rhs
