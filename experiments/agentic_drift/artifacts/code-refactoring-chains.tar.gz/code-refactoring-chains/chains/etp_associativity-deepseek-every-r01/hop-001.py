def law(op, x, y, z):
    left = op(op(x, y), z)
    right = op(x, op(y, z))
    return left == right
