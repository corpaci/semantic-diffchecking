def law(op, x, y, z):
    left_expr = op(op(x, y), z)
    right_expr = op(x, op(y, z))
    return left_expr == right_expr
