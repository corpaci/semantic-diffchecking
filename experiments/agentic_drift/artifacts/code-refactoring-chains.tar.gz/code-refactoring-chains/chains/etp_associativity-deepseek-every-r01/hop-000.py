def law(op, x, y, z):
    return op(op(x, y), z) == op(x, op(y, z))
