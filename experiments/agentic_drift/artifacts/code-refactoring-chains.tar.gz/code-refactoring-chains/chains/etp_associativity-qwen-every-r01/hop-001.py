def law(op, x, y, z):
    left_term = op(op(x, y), z)
    right_term = op(x, op(y, z))
    return left_term == right_term
