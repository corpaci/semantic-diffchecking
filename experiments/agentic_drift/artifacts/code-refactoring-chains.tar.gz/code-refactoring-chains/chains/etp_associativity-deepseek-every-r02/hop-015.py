def law(op, x, y, z):
    left_expression = op(op(x, y), z)
    right_expression = op(x, op(y, z))
    return left_expression == right_expression
