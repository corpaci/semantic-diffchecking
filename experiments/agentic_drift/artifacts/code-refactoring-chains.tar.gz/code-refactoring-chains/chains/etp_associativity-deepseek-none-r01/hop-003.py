def law(op, x, y, z):
    left_side = op(op(x, y), z)
    right_side = op(x, op(y, z))
    return left_side == right_side
