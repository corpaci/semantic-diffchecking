"""Aggregate the saved sweep and check out-of-catalogue laws for counterexamples.

Run with Python 3 and pass the experiment's native-random28-v1 directory.
The script reads saved artifacts, evaluates parsed equations, and makes no API calls.
"""
import argparse
import json
import sys
from collections import Counter
from itertools import product
from pathlib import Path
from random import Random


BOOTSTRAP_SEED = 20261111
BOOTSTRAP_DRAWS = 10_000


def preservation(rows, change_ids):
    """Resample whole source laws, carrying all settings and both directions."""
    laws = sorted({row['node'] for row in rows})
    counts = {law: {d: Counter() for d in ('forward', 'reverse')} for law in laws}
    for row in rows:
        cell = counts[row['node']][row['direction']]
        cell['calls'] += 1
        cell['equivalent'] += row['label'] == 'equivalent'
        cell['changed'] += row['id'] in change_ids

    def bounds(sample, direction):
        total = sum((counts[law][direction] for law in sample), Counter())
        return total['equivalent'] / total['calls'], 1 - total['changed'] / total['calls']

    samples = {d: ([], []) for d in ('forward', 'reverse')}
    rng = Random(BOOTSTRAP_SEED)
    for _ in range(BOOTSTRAP_DRAWS):
        draw = rng.choices(laws, k=len(laws))
        for direction, values in samples.items():
            for series, estimate in zip(values, bounds(draw, direction)):
                series.append(estimate)

    def percentile_interval(series):
        ordered = sorted(series)
        return [ordered[249], ordered[9749]]

    return {
        direction: dict(
            bounds=bounds(laws, direction),
            endpoint_bootstrap_95=[percentile_interval(series) for series in values],
        )
        for direction, values in samples.items()
    }


def truth_test(equation, order, parse_equation, Var):
    eq = parse_equation(equation)

    def variables(term):
        if isinstance(term, Var):
            return {term.name}
        return variables(term.left) | variables(term.right)

    names = sorted(variables(eq.lhs) | variables(eq.rhs))
    positions = {name: i for i, name in enumerate(names)}
    assignments = list(product(range(order), repeat=len(names)))

    def evaluator(term):
        if isinstance(term, Var):
            slot = positions[term.name]
            return lambda table, assignment: assignment[slot]
        left, right = evaluator(term.left), evaluator(term.right)
        return lambda table, assignment: table[
            order * left(table, assignment) + right(table, assignment)
        ]

    lhs, rhs = evaluator(eq.lhs), evaluator(eq.rhs)
    return lambda table: all(lhs(table, a) == rhs(table, a) for a in assignments)


def counterexamples(original, recovered, parse_equation, Var):
    witnesses = {}
    for order in (2, 3):
        intended = truth_test(original, order, parse_equation, Var)
        candidate = truth_test(recovered, order, parse_equation, Var)
        for table in product(range(order), repeat=order * order):
            before, after = intended(table), candidate(table)
            if before != after:
                direction = 'original_implies_generated' if before else 'generated_implies_original'
                witnesses.setdefault(direction, dict(order=order, table=table))
            if len(witnesses) == 2:
                return witnesses
    return witnesses


def raw_choice(run, row_id):
    path = run / 'calls' / row_id / 'transport' / 'events.jsonl'
    for line in path.read_text().splitlines():
        event = json.loads(line)
        if event['kind'] == 'openrouter_raw_response':
            return event['body']['choices'][0]
    raise ValueError(f'Missing response for {row_id}')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('run', type=Path)
    run = cli.parse_args().run.resolve()
    repo = run.parents[3]
    sys.path.insert(0, str(repo / 'translate'))
    from _catalogue import Var, parse_equation

    plan = json.loads((run / 'plan.json').read_text())
    rows = json.loads((run / 'analysis.json').read_text())['records']
    assert [r['id'] for r in rows] == [r['id'] for r in plan['rows']]
    responses = {}
    for row in rows:
        path = run / 'calls' / row['id'] / 'result.json'
        responses[row['id']] = json.loads(path.read_text())['status']
        assert responses[row['id']] == ('truncated' if row['label'] == 'truncated' else 'returned')

    changes = {'incomparable', 'stronger', 'weaker'}
    outside = {}
    cases = {}
    for row in rows:
        if row['label'] in changes or row['label'] == 'outside-fragment':
            item = {k: row[k] for k in ('id', 'node', 'label', 'recovered')}
            item['original'] = plan['laws'][str(row['node'])]
            if row['label'] == 'outside-fragment':
                key = (item['original'], item['recovered'])
                if key not in outside:
                    outside[key] = counterexamples(*key, parse_equation, Var)
                item['witnesses'] = outside[key]
            else:
                item['oracle_evidence'] = row['oracle']['evidence']
            cases[row['id']] = item

    def group(keys):
        groups = {}
        for row in rows:
            key = '/'.join(str(row[k]) for k in keys)
            groups.setdefault(key, Counter())[row['label']] += 1
        return groups

    paired = {}
    for row in rows:
        if row['direction'] == 'forward':
            paired.setdefault((row['node'], row['temperature']), {})[row['size']] = row['label']
    paired_counts = Counter(
        f'{v[14] == "equivalent"}/{v[32] == "equivalent"}'
        for v in paired.values() if 'truncated' not in v.values()
    )
    truncated = [raw_choice(run, r['id']) for r in rows if r['label'] == 'truncated']
    assert all(c['finish_reason'] == 'length' for c in truncated)
    known_changes = [x for x in cases.values() if x['label'] in changes or x.get('witnesses')]
    for item in known_changes:
        witnesses = item.get('witnesses', {})
        item['direction_of_change'] = (
            item['label'] if item['label'] in changes else
            'incomparable' if len(witnesses) == 2 else 'open'
        )
    dates = []
    sampling_seed_sent = False
    for row in rows:
        path = run / 'calls' / row['id'] / 'transport' / 'events.jsonl'
        for line in path.read_text().splitlines():
            event = json.loads(line)
            if event['kind'] == 'openrouter_request':
                dates.append(event['timestamp'])
                sampling_seed_sent |= 'seed' in event['payload']
            elif event['kind'] == 'openrouter_raw_response':
                dates.append(event['timestamp'])
    metrics = dict(
        study_id=plan['study_id'],
        plan_sha256=(run / 'plan.sha256').read_text().strip(),
        equations=len(plan['laws']), calls=len(rows),
        transport=dict(Counter(responses.values())), raw_scores=dict(Counter(r['label'] for r in rows)),
        by_direction=group(['direction']),
        by_model=group(['direction', 'size']),
        by_temperature=group(['temperature', 'direction', 'size']),
        by_format=group(['direction', 'format']),
        oracle_relation=dict(Counter(r['oracle']['label'] for r in rows if 'oracle' in r)),
        paired_completed_forward=paired_counts,
        truncated_empty_answers=sum(not (c['message'].get('content') or '').strip() for c in truncated),
        catalogue_changes=sum(x['label'] in changes for x in known_changes),
        additional_changes=sum(bool(x.get('witnesses')) for x in known_changes),
        changed_equations=sorted({x['node'] for x in known_changes}),
        change_directions=dict(Counter(x['direction_of_change'] for x in known_changes)),
        preservation=preservation(rows, {x['id'] for x in known_changes}),
        bootstrap_seed=BOOTSTRAP_SEED,
        bootstrap_draws=BOOTSTRAP_DRAWS,
        setup=dict(
            models=[{key: config[key] for key in ('model', 'provider', 'reasoning', 'max_tokens')}
                    for config in plan['configs'].values()],
            temperatures=plan['temperatures'], panel_seed=plan['sampling']['seed'],
            generation_seed_sent=sampling_seed_sent,
            first_request_utc=min(dates), last_response_utc=max(dates),
        ),
    )
    graph_case = '2369-graphviz-reverse-32b-t0.6'
    msg = raw_choice(run, graph_case)['message']
    prompt = json.loads((run / 'calls' / graph_case / 'prompt.json').read_text())
    assert 'n7 [label="z"]' in prompt[-1]['content']
    assert 'n7 [label="◇"]' in msg['reasoning']
    cases[graph_case] = dict(
        id=graph_case, original=plan['laws']['2369'],
        input_line='n7 [label="z"];', trace_line='n7 [label="◇"];',
        final_answer=msg['content'],
        same_outcome_at_all_temperatures=[
            r['id'] for r in rows if r['node'] == 2369 and r['size'] == 32
            and r['direction'] == 'reverse' and r['label'] == 'unrecoverable'
        ],
    )
    for name, data in [('metrics.json', metrics), ('case-evidence.json', cases)]:
        Path(__file__).with_name(name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


if __name__ == '__main__':
    main()
