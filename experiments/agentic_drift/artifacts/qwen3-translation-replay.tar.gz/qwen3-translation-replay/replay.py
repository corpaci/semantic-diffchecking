"""Replay oracle scoring and compare all 672 records to the frozen results."""
import json
from pathlib import Path

from experiments.agentic_drift.representation_size_study import analyze, load
from experiments.agentic_drift.openrouter import parse_response

root = Path(__file__).resolve().parent
run = root / 'experiments/agentic_drift/runs/native-random28-v1'
plan = load(run) if Path.cwd() == root else None
if plan is None:
    raise SystemExit('Run this command from the extracted bundle directory')
for row in plan['rows']:
    folder = run / 'calls' / row['id']
    request, response = [json.loads(x) for x in (folder / 'transport/events.jsonl').read_text().splitlines()]
    result = json.loads((folder / 'result.json').read_text())
    assert request['payload']['messages'] == plan['prompts'][row['prompt_id']]
    choice = response['body']['choices'][0]
    if choice['finish_reason'] == 'length':
        assert result['status'] == 'truncated'
    else:
        assert result['status'] == 'returned'
        assert parse_response(response['body']) == result['answer']
analyze(run, plan)
expected = json.loads((root / 'expected-analysis.json').read_text())
actual = json.loads((run / 'analysis.json').read_text())
assert actual == expected
print(f"Reproduced {len(actual['records'])} oracle outcomes.")
