"""Seven bounded, non-executing formats for the equation-to-specification pilot."""
import re

from translate.ssa import ssaify
from translate.py_lambda import lambdify
from translate.smtlib import smtify
from translate.text import textify
from translate.text2 import prefixify
from translate.tptp import tptpify
from _catalogue import Equation, Op, ParseFailure, Var, infix, parse_equation, variables

from .multihop.etp import decode

CONTRACT = ("Use a nonempty domain and one arbitrary pure total binary operation. "
            "Equality is mathematical equality. Every free variable is universally quantified. "
            "Do not assume associativity, commutativity, arithmetic, or any other operation law.")


def formal(equation):
    return f"{infix(equation.lhs)} = {infix(equation.rhs)}"


def specification(equation):
    return CONTRACT + "\nThe required law is: " + prefixify.text_equation(equation)


def read_specification(text):
    prefix = CONTRACT + "\nThe required law is: "
    if not text.startswith(prefix):
        raise ParseFailure("Missing specification contract")
    return prefixify.to_equation(text[len(prefix):])


def bracket(text):
    # Accept only the declared words: do not discard unexpected quantifiers.
    rest = re.sub(r"\b(?:open bracket|close bracket|diamond|equals)\b", " ", text)
    if any(not re.fullmatch(r"[a-z]", word) for word in rest.split()):
        raise ParseFailure("Use bracket words, diamond, equals, and single-letter variables only")
    return textify.to_equation(text)


def numbered(equation):
    lines = []
    for i, line in enumerate(ssaify.render(equation).splitlines(), 1):
        if line.startswith("assert "):
            left, right = line.removeprefix("assert ").split(" = ")
            lines.append(f"{i}. Require {left} and {right} to have the same value.")
        else:
            dest, _, left, _, right = line.split()
            lines.append(f"{i}. Combine {left} as the first input with {right} as the second input; call the result {dest}.")
    return "\n".join(lines)


def read_numbered(text):
    lines = text.splitlines()
    terms = {}

    def term(name):
        if len(name) == 1:
            return Var(name), 1
        if name not in terms:
            raise ParseFailure("Temporary used before definition")
        return terms[name]

    for i, line in enumerate(lines, 1):
        if i == len(lines):
            match = re.fullmatch(rf"{i}\. Require ([a-z]|t\d+) and ([a-z]|t\d+) to have the same value\.", line.strip())
            if match:
                return Equation(term(match[1])[0], term(match[2])[0])
        else:
            match = re.fullmatch(
                rf"{i}\. Combine ([a-z]|t\d+) as the first input with ([a-z]|t\d+) "
                rf"as the second input; call the result (t\d+)\.", line.strip())
            if match:
                left, nl = term(match[1])
                right, nr = term(match[2])
                if match[3] in terms or nl + nr + 1 > 128:
                    raise ParseFailure("Repeated assignment or oversized term")
                terms[match[3]] = Op(left, right), nl + nr + 1
                continue
        raise ParseFailure("Invalid numbered instruction")
    raise ParseFailure("Missing final equality")


def dependencies(equation):
    lines = []

    def visit(term):
        node = f"n{len(lines)+1}"
        index = len(lines)
        lines.append("")
        if isinstance(term, Var):
            lines[index] = f"Node {node} denotes variable {term.name}."
        else:
            left, right = visit(term.left), visit(term.right)
            lines[index] = f"Node {node} combines node {left} as its first input with node {right} as its second input."
        return node

    left, right = visit(equation.lhs), visit(equation.rhs)
    return "\n".join(lines + [f"The values of node {left} and node {right} must be equal."])


def read_dependencies(text):
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    nodes, used, active = {}, set(), set()
    for line in lines[:-1]:
        leaf = re.fullmatch(r"Node (n\d+) denotes variable ([a-z])\.", line)
        branch = re.fullmatch(r"Node (n\d+) combines node (n\d+) as its first input with node (n\d+) as its second input\.", line)
        match = leaf or branch
        if not match or match[1] in nodes:
            raise ParseFailure("Invalid or duplicate node")
        nodes[match[1]] = match.groups()[1:]
    target = re.fullmatch(r"The values of node (n\d+) and node (n\d+) must be equal\.", lines[-1] if lines else "")
    if not target:
        raise ParseFailure("Missing node equality")
    visits = 0

    def visit(node):
        nonlocal visits
        visits += 1
        if visits > 128 or node in active or node not in nodes:
            raise ParseFailure("Cyclic, undefined, or oversized dependency expansion")
        used.add(node)
        active.add(node)
        args = nodes[node]
        term = Var(args[0]) if len(args) == 1 else Op(visit(args[0]), visit(args[1]))
        active.remove(node)
        return term

    result = Equation(visit(target[1]), visit(target[2]))
    if used != nodes.keys():
        raise ParseFailure("Unused node definitions")
    return result


def python_function(equation):
    if not set(variables(equation)) <= {"x", "y", "z"}:
        raise ValueError("P2 pilot supports variables x, y, z")
    lines = ["def law(op, x, y, z):"]
    for line in ssaify.render(equation).splitlines():
        if line.startswith("assert "):
            lines.append("    return " + line.removeprefix("assert ").replace(" = ", " == "))
        else:
            dest, _, left, _, right = line.split()
            lines.append(f"    {dest} = op({left}, {right})")
    return "\n".join(lines)


def read_lambda(text):
    bound, equation = lambdify.read_back(text)
    if set(bound) != set(variables(equation)):
        raise ParseFailure("Lambda arguments do not bind the equation variables")
    return equation


def read_smt(text):
    forms = smtify._forms(text)
    if len(forms) != 3 or forms[:2] != [["declare-sort", "M", "0"], ["declare-fun", "op", ["M", "M"], "M"]]:
        raise ParseFailure("Expected one sort, one binary function, and one assertion")
    equation = smtify.read_back(text)
    if any(sort != "M" for _, sort in forms[2][1][1]):
        raise ParseFailure("Every variable must be bound over M")
    return equation


FORMATS = {
    "T1": ("Bracket English", textify.text_equation, bracket),
    "T3": ("Numbered instructions with single-assignment temporaries", numbered, read_numbered),
    "T5": ("Node dependency facts with ordered operands", dependencies, read_dependencies),
    "P1": ("Single Python lambda with op as first argument", lambdify.py_lambda, read_lambda),
    "P2": ("Python law(op, x, y, z), straight-line op assignments and one equality return",
           python_function, lambda text: parse_equation(decode(text))),
    "P13": ("SMT-LIB, one sort M, one op declaration, and one universally quantified assertion",
            smtify.render, read_smt),
    "P14": ("One universally quantified TPTP fof axiom using op", tptpify.render, tptpify.read_back),
}


def answer_body(text):
    if len(text.encode()) > 16_384:
        raise ParseFailure("Output exceeds the pilot format limit")
    text = text.strip()
    match = re.fullmatch(r"```[\w-]*[ \t]*\n(.*?)\n```", text, re.S)
    if match:
        text = match[1].strip()
    if not text or "```" in text:
        raise ParseFailure("Expected one complete artifact without commentary")
    return text
