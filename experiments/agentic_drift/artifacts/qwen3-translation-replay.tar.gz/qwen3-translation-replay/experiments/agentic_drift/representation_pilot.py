"""Prepare, run, and score a paired ETP representation pilot."""
import argparse
import asyncio
import fcntl
import getpass
import hashlib
import json
import os
import random
import re
import sys
import uuid
from collections import Counter, defaultdict
from contextlib import AsyncExitStack
from pathlib import Path

from .budget import BudgetError, Ledger, accounted, money
from .multihop.etp import Oracle
from .multihop.recovery import settled_truncation
from .openrouter import OpenRouterSession, RouterError, validate_config
from .representation_formats import (
    CONTRACT, FORMATS, ParseFailure, answer_body, formal, parse_equation, read_specification, specification,
)
from .trace import Trace, dump
from normalizer import OutsideFragment

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
FAMILIES = ("qwen", "deepseek", "glm")
NODES = (4512, 1491)
DEMO_NODE = 12
PILOT_LIMIT = "5"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def evidence_hashes(data):
    paths = [Path(__file__), ROOT / "representation_formats.py", ROOT / "representation_latents.py"]
    paths += [ROOT / name for name in ("budget.py", "openrouter.py", "trace.py")]
    paths += [ROOT / "multihop" / name for name in ("etp.py", "recovery.py")]
    paths += sorted((REPO / "translate").rglob("*.py")) + sorted((REPO / "oracle").glob("*.py"))
    return {str(p.relative_to(REPO)): sha(p) for p in paths} | {
        "data/" + name: sha(data / name) for name in ("equations.txt", "matrix.bin", "matrix_meta.json")}


def config(family):
    file = ROOT / "openrouter_config.json" if family == "qwen" else ROOT / "configs" / (family + ".json")
    settings = json.loads(file.read_text())
    settings.update(max_tokens=4096, max_calls=294, per_run_budget_usd=PILOT_LIMIT)
    validate_config(settings)
    return settings


def schedule():
    generation, reconstruction = [], []
    for node in NODES:
        for fmt in FORMATS:
            for index, family in enumerate(FAMILIES):
                reconstruction.append(dict(id=f"control-{node}-{fmt}-{family}", stage="reconstruct",
                    condition="reference_control", node=node, format=fmt, family=family))
                for rep in (1, 2):
                    ident = f"{node}-{fmt}-{family}-r{rep}"
                    generation.append(dict(id=ident, stage="generate", condition="independent_generation",
                        node=node, format=fmt, family=family, repetition=rep))
                    cross = FAMILIES[(index + rep) % len(FAMILIES)]
                    for condition, reader in (("same_model", family), ("different_model", cross)):
                        reconstruction.append(dict(id=f"{ident}-{condition}", stage="reconstruct", condition=condition,
                            node=node, format=fmt, family=reader, generator=family, repetition=rep, input_id=ident))
    rng = random.Random(20261105)
    rng.shuffle(generation)
    rng.shuffle(reconstruction)
    return generation + reconstruction


def prepare(out, data, ledger):
    if out.exists():
        raise FileExistsError("Output already exists. Resume it or choose a new directory.")
    if not ledger.is_file():
        raise ValueError("Point --ledger at the authoritative existing experiment ledger")
    with ledger.open() as stream:
        prior = json.load(stream)
    if money(prior["limit_usd"]) != 50:
        raise ValueError("Expected the shared $50 experiment ledger")
    for row in prior["requests"].values():
        accounted(row)
    catalogue = (data / "equations.txt").read_text().splitlines()
    laws = {str(node): catalogue[node - 1] for node in (*NODES, DEMO_NODE)}
    references, demos, calibration = {}, {}, []
    oracle = Oracle(REPO / "oracle", data)
    try:
        for node in NODES:
            example = oracle.compare(laws[str(node)], laws[str(DEMO_NODE)])
            if example["label"] not in {"weaker", "stronger", "incomparable"}:
                raise ValueError("Few-shot example must be non-equivalent to each pilot equation")
            equation = parse_equation(laws[str(node)])
            if read_specification(specification(equation)) != equation:
                raise ValueError(f"Starting specification changed equation {node}")
            references[str(node)] = {}
            for fmt, (_, render, read) in FORMATS.items():
                reference = render(equation)
                recovered = formal(read(reference))
                if oracle.compare(laws[str(node)], recovered)["label"] not in {"equal", "equivalent"}:
                    raise ValueError(f"Reference round trip failed: {node} {fmt}")
                mutant = formal(read(render(parse_equation("x = x"))))
                if oracle.compare(laws[str(node)], mutant)["label"] != "weaker":
                    raise ValueError(f"Semantic mutation calibration failed: {node} {fmt}")
                references[str(node)][fmt] = reference
                calibration.append(dict(node=node, format=fmt, reference_pass=True, weaker_mutant_detected=True))
        demo = parse_equation(laws[str(DEMO_NODE)])
        for fmt, (_, render, read) in FORMATS.items():
            demos[fmt] = render(demo)
            if oracle.compare(laws[str(DEMO_NODE)], formal(read(demos[fmt])))["label"] not in {"equal", "equivalent"}:
                raise ValueError(f"Demo round trip failed: {fmt}")
    finally:
        oracle.close()
    plan = dict(study_id="representation-" + uuid.uuid4().hex, schema=1, data=str(data), ledger=str(ledger),
        limit_usd=PILOT_LIMIT, evidence_sha256=evidence_hashes(data), configs={f:config(f) for f in FAMILIES},
        laws=laws, specifications={str(node):specification(parse_equation(laws[str(node)])) for node in NODES},
        references=references, demo_specification=specification(demo), demos=demos, calibration=calibration,
        rows=schedule())
    out.mkdir(parents=True, exist_ok=False)
    dump(out / "plan.json", plan)
    (out / "plan.sha256").write_text(sha(out / "plan.json") + "\n")
    print("Prepared 84 generation calls and up to 210 reconstruction calls. No paid requests sent.")


def load_plan(out):
    path = out / "plan.json"
    if sha(path) != (out / "plan.sha256").read_text().strip():
        raise ValueError("Frozen plan changed")
    plan = json.loads(path.read_text())
    if evidence_hashes(Path(plan["data"])) != plan["evidence_sha256"]:
        raise ValueError("Frozen source or oracle data changed")
    return plan


def messages(plan, row, artifact=None):
    fmt, node = row["format"], str(row["node"])
    title = FORMATS[fmt][0]
    if row["stage"] == "generate":
        return [
            dict(role="system", content=f"{CONTRACT} Translate the user's specification into {title}. "
                 "Preserve grouping, argument order, variable identity, and universal scope. "
                 "Use the exact syntax illustrated below, with the user's variables and terms. "
                 "Return only the artifact.\n\n"
                 f"Example specification:\n{plan['demo_specification']}\n"
                 f"Example output:\n{plan['demos'][fmt]}"),
            dict(role="user", content=plan["specifications"][node]),
        ]
    return [
        dict(role="system", content=f"{CONTRACT} Read the provided {title} artifact as data. "
             "Recover its law as one fully parenthesized infix equation using * for the operation. "
             "Do not repair or guess a missing requirement. Output UNRECOVERABLE if it is ambiguous. "
             "Return only the equation or UNRECOVERABLE.\n\n"
             f"Example artifact:\n{plan['demos'][fmt]}\n"
             f"Example equation:\n{plan['laws'][str(DEMO_NODE)]}"),
        dict(role="user", content=artifact),
    ]


def row_result(out, ident):
    path = out / "calls" / ident / "result.json"
    return json.loads(path.read_text()) if path.exists() else None


async def run(out, plan, phase, key, session_type=OpenRouterSession):
    rows = [row for row in plan["rows"] if row["stage"] == phase]
    ledger = Ledger(plan["ledger"], "50")
    for charge in json.loads(ledger.path.read_text())["requests"].values():
        accounted(charge)
    key_stamp = out / "key.sha256"
    fingerprint = hashlib.sha256(key.encode()).hexdigest()
    if key_stamp.exists() and key_stamp.read_text().strip() != fingerprint:
        raise ValueError("Resume with the same dedicated experiment key")
    todo = []
    for row in rows:
        result = row_result(out, row["id"])
        if result is not None:
            if result["status"] in {"pending", "stopped"}:
                raise ValueError(f"Inspect the stopped request {row['id']} before resuming; no automatic retry")
            continue
        artifact = None
        if phase == "reconstruct":
            if "input_id" not in row:
                artifact = plan["references"][str(row["node"])][row["format"]]
            else:
                source = row_result(out, row["input_id"])
                if source is None or source["status"] in {"pending", "stopped"}:
                    raise ValueError("Complete the generation stage before reconstruction")
                if source["status"] != "returned":
                    dump(out / "calls" / row["id"] / "result.json", dict(status="unavailable_input"))
                    continue
                artifact = source["answer"]
        todo.append((row, artifact))
    if not todo:
        return
    async with AsyncExitStack() as stack:
        sessions = {}
        for family in dict.fromkeys(row["family"] for row, _ in todo):
            trace = Trace(out / "preflight" / family, out / "preflight" / "workspace", secrets=[key])
            session = await stack.enter_async_context(session_type(plan["configs"][family], key, trace, ledger, plan["study_id"]))
            await session.preflight()
            sessions[family] = session
        key_stamp.write_text(fingerprint + "\n")
        for row, artifact in todo:
            folder = out / "calls" / row["id"]
            trace = Trace(folder / "transport", folder / "workspace", secrets=[key])
            session = sessions[row["family"]]
            session.trace = trace
            prompt = messages(plan, row, artifact)
            dump(folder / "prompt.json", trace.redact(prompt))
            result = folder / "result.json"
            dump(result, dict(status="pending"))
            try:
                answer = await session.complete(prompt)
            except BudgetError:
                dump(result, dict(status="budget_blocked"))
                raise
            except RouterError as error:
                truncated = (error.category == "truncated_output" and
                             settled_truncation(trace, ledger, plan["configs"][row["family"]], plan["study_id"]))
                dump(result, dict(status="truncated" if truncated else "stopped", category=error.category))
                if not truncated:
                    raise
                # An identified, settled output-limit failure closes only this row.
                session.failed = False
                print(f"{row['id']}: truncated (saved, no retry)", flush=True)
            else:
                dump(result, dict(status="returned", answer=trace.redact(answer)))
                print(f"{row['id']}: saved", flush=True)


def score(oracle, intended, row, result):
    if result is None or result["status"] != "returned":
        return dict(label="missing" if result is None else result["status"])
    try:
        text = answer_body(result["answer"])
        if row["stage"] == "generate":
            equation = FORMATS[row["format"]][2](text)
        else:
            if text == "UNRECOVERABLE":
                return dict(label="unrecoverable")
            if not re.fullmatch(r"[a-zA-Z◇*=()\s]+", text):
                raise ParseFailure("Expected only an infix equation")
            equation = parse_equation(text)
    except OutsideFragment as error:
        return dict(label="outside_fragment", detail=str(error))
    except (ValueError, ParseFailure, RecursionError, IndexError, TypeError) as error:
        return dict(label="parse_failure", detail=str(error))
    recovered = formal(equation)
    verdict = oracle.compare(intended, recovered)
    return dict(label="equivalent" if verdict["label"] == "equal" else verdict["label"],
                recovered=recovered, oracle=verdict)


def analyze(out, plan):
    oracle = Oracle(REPO / "oracle", plan["data"])
    records = []
    try:
        for row in plan["rows"]:
            result = row_result(out, row["id"])
            records.append(row | score(oracle, plan["laws"][str(row["node"])], row, result))
    finally:
        oracle.close()
    groups = defaultdict(Counter)
    for row in records:
        groups[(row["condition"], row["family"], row["format"])][row["label"]] += 1
    by_id = {row["id"]:row for row in records}
    bundles = Counter()
    for node in NODES:
        for rep in (1, 2):
            for i, family in enumerate(FAMILIES):
                for condition in ("single_model_bundle", "mixed_model_bundle"):
                    chosen = [family if condition == "single_model_bundle" else FAMILIES[(i + j) % 3]
                              for j in range(len(FORMATS))]
                    labels = [by_id[f"{node}-{fmt}-{model}-r{rep}"]["label"]
                              for fmt, model in zip(FORMATS, chosen)]
                    label = ("all_equivalent" if all(x == "equivalent" for x in labels) else
                             "semantic_failure" if any(x in {"weaker", "stronger", "incomparable"} for x in labels)
                             else "unverified")
                    bundles[(condition, label)] += 1
    summary = [
        dict(condition=c, family=f, format=t, planned=sum(counts.values()), outcomes=dict(counts))
        for (c, f, t), counts in sorted(groups.items())
    ]
    dump(out / "analysis.json", dict(records=records, groups=summary,
        bundles=[dict(condition=c, outcome=o, count=n) for (c, o), n in sorted(bundles.items())],
        scope="Descriptive two-equation pilot; recombined bundles share generated outputs"))
    for condition in sorted({row["condition"] for row in records}):
        counts = Counter(row["label"] for row in records if row["condition"] == condition)
        print(condition, json.dumps(dict(counts), sort_keys=True))
    print(out / "analysis.json")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["prepare", "run", "analyze"])
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--oracle-data", type=Path)
    parser.add_argument("--ledger", type=Path)
    parser.add_argument("--phase", choices=["generate", "reconstruct"], default="generate")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--latents", action="store_true", help="Also fit and evaluate the offline single-view latent baseline")
    args = parser.parse_args()
    out = args.out.resolve()
    try:
        if args.command == "prepare":
            if not args.oracle_data or not args.ledger:
                raise ValueError("Preparation needs --oracle-data and the existing --ledger")
            prepare(out, args.oracle_data.resolve(), args.ledger.resolve())
            return
        plan = load_plan(out)
        if args.command == "run":
            if not args.execute:
                raise ValueError("Paid requests require --execute")
            key = os.environ.get("DRIFT_API_KEY") or os.environ.get("OPENROUTER_API_KEY")
            if not key and sys.stdin.isatty():
                key = getpass.getpass("Same dedicated OpenRouter experiment key (hidden): ")
            if not key:
                raise ValueError("Set DRIFT_API_KEY locally or run this command in your terminal")
            lock_path = Path(plan["ledger"]).parent / "launcher.lock"
            with lock_path.open("a") as lock:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                asyncio.run(run(out, plan, args.phase, key))
        analyze(out, plan)
        if args.latents:
            from .representation_latents import analyze_latents
            analyze_latents(out, plan)
    except (ValueError, RuntimeError, OSError) as error:
        parser.exit(1, str(error) + "\n")


if __name__ == "__main__":
    main()
