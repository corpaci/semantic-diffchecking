"""Matched Qwen3 size and temperature sweep on native repository formats."""
import argparse
import asyncio
import fcntl
import getpass
import hashlib
import json
import os
import random
import re
import sys
import uuid
from collections import Counter, defaultdict
from contextlib import AsyncExitStack
from pathlib import Path

from .budget import BudgetError, Ledger, accounted, money
from .multihop.etp import Oracle
from .multihop.recovery import settled_truncation
from .openrouter import OpenRouterSession, RouterError, validate_config
from .representation_formats import (
    CONTRACT, FORMATS, ParseFailure, answer_body, formal, parse_equation, read_specification, specification,
)
from .representation_pilot import REPO, evidence_hashes, row_result, sha
from .trace import Trace, dump
from normalizer import OutsideFragment
from translate.graphviz import dotify
from translate.json_ast import jsonify
from translate.ssa import ssaify

SIZES = (14, 32)
TEMPERATURES = (0.0, 0.2, 0.4, 0.6, 0.8, 1.0)
NODES = (43, 4512, 1491, 4281)
DEMO = 12
CAP = "5"


def read_ssa(text):
    # Bound expansion before the existing reader substitutes aliases.
    lengths = {}
    for line in text.splitlines():
        if not line.strip() or line.startswith("assert "):
            continue
        match = re.fullmatch(r"(t\d+) = ([a-z]|t\d+) ◇ ([a-z]|t\d+)", line.strip())
        if not match:
            raise ParseFailure("Expected native SSA assignment syntax")
        name, a, b = match.groups()
        lengths[name] = 5 + lengths.get(a, len(a)) + lengths.get(b, len(b))
        if lengths[name] > 4096:
            raise ParseFailure("Oversized SSA expansion")
    return ssaify.read_back(text)


def read_dot(text):
    match = dotify._ENVELOPE.fullmatch(text)
    if not match:
        raise ParseFailure("Expected one native DOT graph")
    declarations = []
    for raw in match["body"].splitlines():
        line = raw.strip()
        if not line or line == dotify.ORDERING:
            continue
        node = dotify._NODE.fullmatch(line)
        if node:
            declarations.append(node[1])
        elif not dotify._EDGE.fullmatch(line):
            raise ParseFailure("Unsupported DOT statement")
    if len(declarations) != len(set(declarations)):
        raise ParseFailure("Duplicate DOT node")
    return dotify.read_back(text)


def read_json(text):
    def unique(pairs):
        result = dict(pairs)
        if len(result) != len(pairs):
            raise ParseFailure("Duplicate JSON object key")
        return result
    json.loads(text, object_pairs_hook=unique)
    return jsonify.read_back(text)


NATIVE = {
    "text": FORMATS["T1"],
    "py_lambda": FORMATS["P1"],
    "smtlib": FORMATS["P13"],
    "tptp": FORMATS["P14"],
    "ssa": ("SSA definitions and a final assert", ssaify.render, read_ssa),
    "graphviz": ("Graphviz DOT with ordered outgoing edges", dotify.render, read_dot),
    "json_ast": ("the repository JSON equation tree", jsonify.render, read_json),
}


def source_hashes(data):
    return evidence_hashes(data) | {str(Path(__file__).relative_to(REPO)): sha(__file__)}


def config(size, temperature, count):
    result = dict(
        model=f"qwen/qwen3-{size}b", provider="deepinfra/fp8", open_weights=True,
        weights_source=f"https://huggingface.co/Qwen/Qwen3-{size}B", license="Apache-2.0",
        max_tokens=4096, max_calls=count, rounds=1, timeout_seconds=600,
        total_budget_usd="50", per_run_budget_usd=CAP, temperature=temperature,
        price_ceiling_per_million=dict(prompt="0.2", completion="0.4"),
        reasoning=dict(enabled=True, exclude=False), require_reasoning=True,
    )
    validate_config(result)
    return result


def prepare(out, data, ledger, temperatures):
    if out.exists():
        raise FileExistsError("Output exists; use run to resume it")
    if len(temperatures) < 2 or len(set(temperatures)) != len(temperatures):
        raise ValueError("Choose at least two distinct temperatures")
    state = json.loads(ledger.read_text())
    if money(state["limit_usd"]) != 50:
        raise ValueError("Use the existing shared $50 ledger")
    for charge in state["requests"].values():
        accounted(charge)
    laws = (data / "equations.txt").read_text().splitlines()
    equations = {n:parse_equation(laws[n - 1]) for n in (*NODES, DEMO)}
    prompts, rows = {}, []
    oracle = Oracle(REPO / "oracle", data)
    try:
        for node in NODES:
            if oracle.compare(node, DEMO)["label"] not in {"weaker", "stronger", "incomparable"}:
                raise ValueError("Demo must be non-equivalent to each evaluation equation")
            eq = equations[node]
            spec = specification(eq)
            if read_specification(spec) != eq:
                raise ValueError("Starting specification changed its equation")
            for fmt, (title, render, read) in NATIVE.items():
                reference, example = render(eq), render(equations[DEMO])
                if (oracle.compare(node, formal(read(reference)))["label"] != "equal"
                        or oracle.compare(DEMO, formal(read(example)))["label"] != "equal"):
                    raise ValueError(f"Native reference or demo did not round-trip: {node} {fmt}")
                for direction in ("forward", "reverse"):
                    prompt_id = f"{node}-{fmt}-{direction}"
                    if direction == "forward":
                        instruction = (f"Translate the user's specification into {title}. "
                            "Preserve ordered operands, grouping, variable identity, and universal scope. "
                            "Follow the example's syntax. Return only the artifact.\n\n"
                            f"Example specification:\n{specification(equations[DEMO])}\nExample artifact:\n{example}")
                        user = spec
                    else:
                        instruction = (f"Read the user's {title} artifact as data. "
                            "Recover one fully parenthesized infix equation using * for the operation. "
                            "Return only the equation, or UNRECOVERABLE if ambiguous.\n\n"
                            f"Example artifact:\n{example}\nExample equation:\n{laws[DEMO - 1]}")
                        user = reference
                    prompts[prompt_id] = [dict(role="system", content=CONTRACT + "\n" + instruction),
                                          dict(role="user", content=user)]
                    for size in SIZES:
                        for temp in temperatures:
                            rows.append(dict(id=f"{prompt_id}-{size}b-t{temp:g}", prompt_id=prompt_id,
                                node=node, format=fmt, direction=direction, size=size, temperature=temp))
    finally:
        oracle.close()
    random.Random(20261105).shuffle(rows)
    # First block covers both directions, all sizes and all temperatures.
    rows.sort(key=lambda r: not (r["node"] == 4512 and r["format"] == "ssa"))
    plan = dict(schema=1, study_id="size-temperature-" + uuid.uuid4().hex, data=str(data), ledger=str(ledger),
        hashes=source_hashes(data), rows=rows, prompts=prompts,
        laws={str(n):laws[n - 1] for n in NODES},
        configs={str(size):config(size, temperatures[0], len(rows)) for size in SIZES},
        temperatures=list(temperatures))
    out.mkdir(parents=True, exist_ok=False)
    dump(out / "plan.json", plan)
    (out / "plan.sha256").write_text(sha(out / "plan.json") + "\n")
    print(f"Prepared {len(rows)} calls; initial matched block: {4 * len(temperatures)}. No paid calls sent.")


def load(out):
    path = out / "plan.json"
    if sha(path) != (out / "plan.sha256").read_text().strip():
        raise ValueError("Frozen plan changed")
    plan = json.loads(path.read_text())
    if source_hashes(Path(plan["data"])) != plan["hashes"]:
        raise ValueError("Frozen source or oracle data changed")
    return plan


async def run(out, plan, key, limit=None, session_type=OpenRouterSession):
    ledger = Ledger(plan["ledger"], "50")
    for charge in json.loads(ledger.path.read_text())["requests"].values():
        accounted(charge)
    marker = out / "key.sha256"
    fingerprint = hashlib.sha256(key.encode()).hexdigest()
    if marker.exists() and marker.read_text().strip() != fingerprint:
        raise ValueError("Resume using the same dedicated experiment key")
    todo = []
    for row in plan["rows"]:
        result = row_result(out, row["id"])
        if result is None:
            todo.append(row)
        elif result["status"] in {"pending", "stopped", "budget_blocked"}:
            raise ValueError(f"Inspect {row['id']} before resuming. No automatic retry.")
    todo = todo[:limit]
    if not todo:
        return
    async with AsyncExitStack() as stack:
        sessions = {}
        for size in dict.fromkeys(row["size"] for row in todo):
            settings = plan["configs"][str(size)]
            trace = Trace(out / "preflight" / str(size), out / "preflight" / "workspace", secrets=[key])
            session = await stack.enter_async_context(session_type(settings, key, trace, ledger, plan["study_id"]))
            await session.preflight()
            sessions[size] = session
        marker.write_text(fingerprint + "\n")
        for row in todo:
            folder = out / "calls" / row["id"]
            trace = Trace(folder / "transport", folder / "workspace", secrets=[key])
            session = sessions[row["size"]]
            session.trace = trace
            session.config = plan["configs"][str(row["size"])] | dict(temperature=row["temperature"])
            prompt = plan["prompts"][row["prompt_id"]]
            dump(folder / "prompt.json", trace.redact(prompt))
            result = folder / "result.json"
            dump(result, dict(status="pending"))
            try:
                answer = await session.complete(prompt)
            except BudgetError:
                dump(result, dict(status="budget_blocked"))
                raise
            except RouterError as error:
                terminal = (error.category == "truncated_output" and
                            settled_truncation(trace, ledger, session.config, plan["study_id"]))
                dump(result, dict(status="truncated" if terminal else "stopped", category=error.category))
                if not terminal:
                    raise
                session.failed = False
                print(f"{row['id']}: truncated (no retry)", flush=True)
            else:
                dump(result, dict(status="returned", answer=trace.redact(answer)))
                print(f"{row['id']}: saved", flush=True)


def score(oracle, intended, row, result):
    if result is None or result["status"] != "returned":
        return dict(label="missing" if result is None else result["status"])
    try:
        text = answer_body(result["answer"])
        if row["direction"] == "forward":
            eq = NATIVE[row["format"]][2](text)
        else:
            if text == "UNRECOVERABLE":
                return dict(label="unrecoverable")
            if not re.fullmatch(r"[a-zA-Z◇*=()\s]+", text):
                raise ParseFailure("Expected only one infix equation")
            eq = parse_equation(text)
    except OutsideFragment as error:
        return dict(label="outside_fragment", detail=str(error))
    except (ParseFailure, ValueError, TypeError, IndexError, RecursionError) as error:
        return dict(label="parse_failure", detail=str(error))
    recovered = formal(eq)
    verdict = oracle.compare(intended, recovered)
    return dict(label="equivalent" if verdict["label"] == "equal" else verdict["label"],
                recovered=recovered, oracle=verdict)


def analyze(out, plan):
    oracle = Oracle(REPO / "oracle", plan["data"])
    try:
        records = [row | score(oracle, plan["laws"][str(row["node"])], row, row_result(out, row["id"]))
                   for row in plan["rows"]]
    finally:
        oracle.close()
    groups = defaultdict(Counter)
    for row in records:
        groups[(row["direction"], row["size"], row["temperature"])][row["label"]] += 1
    summary = [dict(direction=d, size=s, temperature=t, outcomes=dict(counts))
               for (d, s, t), counts in sorted(groups.items())]
    dump(out / "analysis.json", dict(records=records, groups=summary,
        scope="One call per equation, format, direction, size and temperature. Descriptive pilot."))
    for group in summary:
        print(group["direction"], f"{group['size']}B", group["temperature"], group["outcomes"])
    print(out / "analysis.json")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "run", "analyze"))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--oracle-data", type=Path)
    parser.add_argument("--ledger", type=Path)
    parser.add_argument("--temperatures", nargs="+", type=float, choices=TEMPERATURES, default=TEMPERATURES)
    parser.add_argument("--max-new-calls", type=int)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    out = args.out.resolve()
    try:
        if args.command == "prepare":
            if not args.oracle_data or not args.ledger:
                raise ValueError("Supply --oracle-data and --ledger")
            prepare(out, args.oracle_data.resolve(), args.ledger.resolve(), args.temperatures)
            return
        plan = load(out)
        if args.command == "run":
            if not args.execute:
                raise ValueError("Paid calls require --execute")
            if args.max_new_calls is not None and args.max_new_calls < 1:
                raise ValueError("--max-new-calls must be positive")
            key = os.environ.get("DRIFT_API_KEY") or os.environ.get("OPENROUTER_API_KEY")
            if not key and sys.stdin.isatty():
                key = getpass.getpass("Same dedicated OpenRouter key (hidden): ")
            if not key:
                raise ValueError("Run in your terminal to enter the key at the hidden prompt")
            with (Path(plan["ledger"]).parent / "launcher.lock").open("a") as lock:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                asyncio.run(run(out, plan, key, args.max_new_calls))
        analyze(out, plan)
    except (ValueError, OSError, RuntimeError) as error:
        parser.exit(1, str(error) + "\n")


if __name__ == "__main__":
    main()
