"""Single-view adaptation of PR #15's raw latent relation classifier."""
import json
from collections import Counter
from pathlib import Path

from .representation_formats import FORMATS, parse_equation, variables
from .trace import dump

METHOD = "single-view char TF-IDF, centered SVD, directional pair features, HGB"


def analyze_latents(out, plan):
    import numpy as np
    import sklearn
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics import confusion_matrix, precision_recall_fscore_support
    from threadpoolctl import threadpool_limits

    from .representation_pilot import DEMO_NODE, NODES, row_result

    records = json.loads((out / "analysis.json").read_text())["records"]
    generated = [r for r in records if r["stage"] == "generate" and
                 (row_result(out, r["id"]) or {}).get("status") == "returned"]
    if not generated:
        raise ValueError("Generate some pilot outputs before running the latent evaluator")
    rng = np.random.default_rng(20261105)
    data = Path(plan["data"])
    catalogue = (data / "equations.txt").read_text().splitlines()
    n = len(catalogue)
    matrix = np.memmap(data / "matrix.bin", dtype="uint8", mode="r", shape=(n, n))
    excluded = np.zeros(n, dtype=bool)
    for node in (*NODES, DEMO_NODE):
        i = node - 1
        excluded[i] = True
        excluded |= (matrix[i] == 1) & (matrix[:, i] == 1)
    nodes = []
    equations = []
    for i in rng.permutation(n):
        if excluded[i]:
            continue
        eq = parse_equation(catalogue[i])
        if set(variables(eq)) <= {"x", "y", "z"}:
            nodes.append(int(i))
            equations.append(eq)
        if len(nodes) == 320:
            break
    ix, iy = np.triu_indices(len(nodes), 1)
    ids = np.asarray(nodes)
    forward, backward = matrix[ids[ix], ids[iy]], matrix[ids[iy], ids[ix]]
    labels = ("equivalent", "stronger", "weaker", "incomparable")
    # Include both directions, then balance resolved pairs by class.
    ix, iy = np.r_[ix, iy], np.r_[iy, ix]
    forward, backward = np.r_[forward, backward], np.r_[backward, forward]
    y = np.where(forward == 1, np.where(backward == 1, 0, 2), np.where(backward == 1, 1, 3))
    known = (forward <= 1) & (backward <= 1)
    picks = []
    for label in range(4):
        indices = np.flatnonzero(known & (y == label))
        if not len(indices):
            raise ValueError(f"Missing training examples for {labels[label]}")
        picks.extend(rng.choice(indices, min(400, len(indices)), replace=False).tolist())
    y, ix, iy = y[picks], ix[picks], iy[picks]
    predictions = []
    with threadpool_limits(limits=1):
        for fmt, (_, render, _) in FORMATS.items():
            rows = [r for r in generated if r["format"] == fmt]
            if not rows:
                continue
            training = [render(eq) for eq in equations]
            vectorizer = TfidfVectorizer(analyzer="char", ngram_range=(2, 4), max_features=500)
            features = vectorizer.fit_transform(training).toarray()
            mean = features.mean(axis=0)
            _, _, basis = np.linalg.svd(features - mean, full_matrices=False)
            basis = basis[:8].T

            def pair(a, b):
                return np.concatenate([a, b, a - b], axis=1)

            z = (features - mean) @ basis
            clf = HistGradientBoostingClassifier(max_iter=100, max_depth=4, random_state=42)
            clf.fit(pair(z[ix], z[iy]), y)
            reference = [plan["references"][str(r["node"])][fmt] for r in rows]
            # Use the actual returned strings, including malformed outputs.
            candidate = [row_result(out, r["id"])["answer"] for r in rows]
            a = (vectorizer.transform(reference).toarray() - mean) @ basis
            b = (vectorizer.transform(candidate).toarray() - mean) @ basis
            predictions.extend(dict(id=r["id"], format=fmt, oracle=r["label"], predicted=labels[int(pred)])
                               for r, pred in zip(rows, clf.predict(pair(a, b))))
    resolved = [r for r in predictions if r["oracle"] in labels]
    stats = None
    if resolved:
        gold, pred = [r["oracle"] for r in resolved], [r["predicted"] for r in resolved]
        precision, recall, f1, support = precision_recall_fscore_support(gold, pred, labels=labels, zero_division=0)
        matrix4 = confusion_matrix(gold, pred, labels=labels)
        true_equivalent = matrix4[0, 0]
        false_equivalent = matrix4[1:, 0].sum()
        non_equivalent = matrix4[1:, :].sum()
        stats = dict(confusion=matrix4.tolist(), accuracy=float(np.mean(np.asarray(gold) == np.asarray(pred))),
            per_label={label:dict(precision=float(p), recall=float(r), f1=float(f), support=int(s))
                       for label, p, r, f, s in zip(labels, precision, recall, f1, support)},
            macro_f1=float(f1.mean()) if all(support) else None,
            equivalence_precision=float(true_equivalent / (true_equivalent + false_equivalent))
                if true_equivalent + false_equivalent else None,
            equivalence_specificity=float(1 - false_equivalent / non_equivalent) if non_equivalent else None)
    dump(out / "latent-analysis.json", dict(method=METHOD, sklearn=sklearn.__version__,
        training_nodes=[i+1 for i in nodes], training_labels=dict(Counter(labels[i] for i in y)),
        labels=list(labels), scored_outputs=len(predictions), oracle_resolved=len(resolved),
        metrics=stats, predictions=predictions,
        scope="Exploratory single-view adaptation, not the original 19-view classifier. Missing oracle labels are excluded from metric accuracy."))
    print(f"Latent predictions: {len(predictions)}; oracle-resolved: {len(resolved)}")
    print(out / "latent-analysis.json")
