# Qwen3 translation pilot replay

From this directory, run Python 3.11 or later.

    python3 replay.py
    python3 analyze.py experiments/agentic_drift/runs/native-random28-v1

The replay checks all saved answers against their archived API responses and
recomputes all strict scores. The second command recalculates the finite
witnesses and law-level bootstrap. Both operate offline.

The bundle includes the exact prompts, saved answers, provider response bodies
with reasoning, source code and oracle data. It omits API credentials, charge
ledgers, transport identifiers and the original machine paths. The portable
plan records the original plan hash and retains the original source hashes.
